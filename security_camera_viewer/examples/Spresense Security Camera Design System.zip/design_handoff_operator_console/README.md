# Handoff: Spresense 防犯カメラ — Rust + egui 操作コンソール

## 概要 / Overview

Sony Spresense ボード（CXD5602 + ISX012 HDR カメラ）から USB CDC 経由で MJPEG 映像を受信する **PC 操作コンソール** の UI を、Rust + `eframe`/`egui` で実装するためのハンドオフパッケージです。本デザインシステムで作成した HTML プロトタイプを、Rust 側のネイティブ実装に置き換えるための仕様書として利用してください。

参照仕様書（リポジトリ内）：`docs/security_camera/06_SOFTWARE_SPEC_PC_RUST.md`

## このバンドルについて / About the Design Files

このフォルダ内の HTML ファイルは **デザインリファレンス**（プロトタイプ）であり、そのまま組み込む production コードではありません。タスクは、これらの HTML デザインを **Rust + egui の既存環境内で再現** することです。レイアウト、寸法、色、文言、ステータスマシン、計測値の見せ方を仕様として読み取り、`egui` のネイティブウィジェット（`egui::SidePanel`、`egui::TopBottomPanel`、`egui::CentralPanel`、`Frame`、`Stroke` など）で構成し直してください。

## 忠実度 / Fidelity

**Hi-fi（高忠実度）。** 配色、タイポグラフィ、余白、アニメーションすべて確定済。色は `assets/colors_and_type.css` の CSS カスタムプロパティを Rust の `egui::Color32` 定数として写し取り、`Visuals` / `Style` にバインドしてください。レイアウトは egui の単位（pt/px）に読み替えで構いませんが、**比率と階層は HTML と一致させること**。

## 画面 / Screens

### 操作コンソール（メインウィンドウ）

- **目的：** カメラとの USB-CDC 接続の確立、ライブ映像の表示、録画制御、計測値・ログの常時監視
- **レイアウト：** 4領域構成（参照：`ui_kits/operator_console/index.html`）
  - **トップバー（高さ 40px）：** 左にロゴ + タイトル `SPRESENSE · 防犯カメラ操作コンソール`、中央にデバイスパス（mono）、右にステータスピル + 設定/電源アイコン
  - **左レール（幅 56px 折畳／220px 展開）：** ストリーム / 録画 / ファイル / 統計 / デバイス / ヘルプ
  - **中央：** 上部にライブビューポート（16:9、HUD 付き）、下部に計測値ストリップ（6セル）
  - **右インスペクタ（幅 340px）：** 接続パネル、録画コントロール
  - **下部ログストリップ（高さ 160px、リサイズ可）：** フィルタ + ログ末尾
- **ステータスマシン：** `OFFLINE → LINK → LIVE`、いずれの状態からも `FAULT` へ遷移可

### コンポーネント詳細

すべて HTML 側の JSX ファイルに 1:1 対応：

| HTML コンポーネント | Rust モジュール案 | 役割 |
|---|---|---|
| `Shell.jsx` (TopBar/LeftRail/RightInspector/BottomLog) | `ui::shell` | ウィンドウのフレーム |
| `Viewport.jsx` | `ui::viewport` | ライブ映像 + HUD（タイムスタンプ、フレーム#、REC、十字線） |
| `TelemetryStrip.jsx` | `ui::telemetry` | 6セル計測値（配信/FPS/ビットレート/遅延/フレーム数/CRCエラー） |
| `ConnectionPanel.jsx` | `ui::connection` | デバイス選択、ボーレート、接続/切断 |
| `RecordingControls.jsx` | `ui::recording` | 録画開始/停止、ストレージゲージ |
| `LogStrip.jsx` | `ui::log_strip` | ログ末尾、フィルタ、レベル別色 |

## デザイントークン / Design Tokens

すべて `colors_and_type.css` のダークテーマ既定値から。Rust では `Color32::from_rgb(...)` の定数として定義してください。

```rust
// 推奨: src/ui/tokens.rs
use egui::Color32;

// Surfaces
pub const BG_0: Color32 = Color32::from_rgb(0x0a, 0x0c, 0x10); // 深い墨
pub const BG_1: Color32 = Color32::from_rgb(0x11, 0x14, 0x1a);
pub const BG_2: Color32 = Color32::from_rgb(0x18, 0x1c, 0x24);
pub const BG_3: Color32 = Color32::from_rgb(0x20, 0x25, 0x2f);
pub const BG_4: Color32 = Color32::from_rgb(0x2a, 0x31, 0x40);

// Foreground
pub const FG_1: Color32 = Color32::from_rgb(0xe8, 0xec, 0xf4);
pub const FG_2: Color32 = Color32::from_rgb(0xb0, 0xb8, 0xc7);
pub const FG_3: Color32 = Color32::from_rgb(0x6c, 0x76, 0x89);
pub const FG_4: Color32 = Color32::from_rgb(0x42, 0x4b, 0x5c);

// Borders
pub const BORDER_1: Color32 = Color32::from_rgb(0x23, 0x29, 0x36);
pub const BORDER_2: Color32 = Color32::from_rgb(0x2f, 0x36, 0x45);

// Accent (warm amber)
pub const ACCENT: Color32 = Color32::from_rgb(0xd9, 0x9a, 0x3d);
pub const ACCENT_HI: Color32 = Color32::from_rgb(0xe8, 0xb2, 0x5c);
pub const ACCENT_LO: Color32 = Color32::from_rgb(0xb0, 0x7d, 0x2c);

// Status
pub const STATUS_LIVE: Color32 = Color32::from_rgb(0xe8, 0x4a, 0x4a);
pub const STATUS_READY: Color32 = Color32::from_rgb(0x4a, 0xd2, 0x7a);
pub const STATUS_LINK: Color32 = ACCENT;
pub const STATUS_OFFLINE: Color32 = FG_3;
pub const STATUS_FAULT: Color32 = Color32::from_rgb(0xff, 0x5a, 0x5a);
```

### 余白 / Spacing
4px スケール: 4, 8, 12, 16, 20, 24, 32, 40, 48, 56, 64

### 角丸 / Radius
- 入力欄: 2px / カード・パネル: 4px / モーダル: 8px / ステータスドット: full circle のみ

### タイポグラフィ
- ディスプレイ: **Space Grotesk**（見出し、UIラベル）
- 本文: **IBM Plex Sans** / **IBM Plex Sans JP**
- モノ: **JetBrains Mono**（数値、識別子、ログ — 必ず `tabular_nums`）
- スケール: 11/12/13/14/16/18/22/28/36/48/64 px

egui では `FontDefinitions` で 4ファミリ登録 → `TextStyle::Heading/Body/Monospace` にマップ。日本語フォントは `IBMPlexSansJP-Regular.woff2` の TTF 版を `egui` の `font_data` に登録してください。

## 文言 / Copy（日本語主体）

正確に再現してください：

- ステータス: `配信中 · LIVE` / `待機 · READY` / `接続中 · LINK` / `切断 · OFFLINE` / `障害 · FAULT`
- ボタン: `接続` / `切断` / `録画開始` / `停止 · {hh:mm:ss}` / `障害シミュレート`
- 左レール: `ストリーム` / `録画` / `ファイル` / `統計` / `デバイス` / `ヘルプ`
- パネル見出し: `接続 · CONNECTION` / `録画 · RECORDING` / `ストレージ` / `ログ · LOG TAIL`
- 計測値ラベル: `配信` / `FPS` / `ビットレート` / `遅延` / `フレーム数` / `CRC エラー`
- ビューポート: `信号なし · NO SIGNAL` / `ハンドシェイク中...` / `障害 · E0x07`

## 振る舞い / Interactions

- **接続：** ボタン押下 → `OFFLINE → LINK`（ハンドシェイク 1.4秒のシミュレート、実機は `magic=0x5350`、`ver=0x01` の交換）→ `LIVE`
- **アニメーション：**
  - 録画ドット: 1Hz 点滅（`opacity 1 ↔ 0.35`）
  - LINK ドット: 2Hz 点滅（`opacity 1 ↔ 0.5`）
  - ホバー: 120ms ease-out で背景 1段
- **HUD：** `LIVE` 中はタイムスタンプ（右上）、`F#000123` フレーム番号（左下）、`録画 · hh:mm:ss`（右下）を常時表示
- **ログ：** 末尾固定スクロール、レベル別色（INFO=`FG_2` / OK=`STATUS_READY` / WARN=`ACCENT` / FAULT=`STATUS_FAULT`）

## State / 状態管理

```rust
struct AppState {
    status: ConnState,         // OFFLINE / LINK / LIVE / FAULT
    device: Option<String>,    // "/dev/ttyACM0"
    recording: bool,
    rec_start: Option<Instant>,
    frames: u64,
    crc_errs: u32,
    log: VecDeque<LogEntry>,   // 末尾固定、上限 1000 行
    storage_used_gb: u32,
    storage_total_gb: u32,
}
```

接続スレッドは `tokio` + `tokio-serial`、フレーム受信は別スレッドで `mpsc::channel` 経由 UI へ。`egui` UI スレッドは 60fps 更新。

## アセット / Assets

- `assets/logo.svg` — 採用ロゴ（**C: ピクセルグリッド**、JetBrains Mono ワードマーク）
- `assets/glyph.svg` — グリフ単体（タスクバー/タイトルバー用）
- `colors_and_type.css` — トークンの正本

ロゴは `egui` の `Image` ウィジェットで PNG ラスタ（`@1x/@2x` の 22px / 44px 高）として焼き込みを推奨。SVG 直接ロードする場合は `usvg` + `resvg` クレートを使用。

## ファイル / Files

このバンドル内：

- `README.md` — 本ファイル
- `colors_and_type.css` — デザイントークン（CSS カスタムプロパティの正本）
- `assets/logo.svg`, `assets/glyph.svg` — 採用ロゴ（C案）
- `ui_kits/operator_console/` — 操作コンソールの HTML プロトタイプ一式（`index.html` + 各 JSX）
- `slides/phase-review.html` — 同じトークンを使ったスライド例（タイポ・色の感覚確認用）

## 推奨クレート

```toml
eframe = "0.27"
egui = "0.27"
egui_extras = { version = "0.27", features = ["image", "svg"] }
tokio = { version = "1", features = ["full"] }
tokio-serial = "5"
ffmpeg-next = "7"
image = "0.25"
parking_lot = "0.12"
```

## 実装順序の提案

1. `tokens.rs` でカラー・フォント定義 → `Visuals` / `Style` に流し込み
2. `Shell`（4ペイン構成）の骨組みだけ先に組む
3. `ConnectionPanel`（モック接続でステートマシン動作確認）
4. `Viewport`（プレースホルダ + HUD レイヤ）
5. `TelemetryStrip` + `LogStrip`（ダミーデータ駆動）
6. ここで HTML プロトタイプと並べてビジュアル一致を取る
7. 実機 USB-CDC 接続を `tokio-serial` で接続、SCBP プロトコル実装
8. `ffmpeg-next` で MJPEG デコード → `Viewport` へテクスチャ供給
9. `RecordingControls` で MP4 セグメント書き出し

---

ご不明点や、egui 特有の API（例：`Frame::group` で hairline 罫線、`Stroke::new(1.0, BORDER_1)` の使い分けなど）は HTML 側の `styles.css` を参照してください。
