// Viewport.jsx — live 16:9 viewport with HUD
function Viewport({ status, recording, recElapsed, frameCount, timestamp }) {
  return (
    <div className="vp">
      <div className="vp__crosshair" />
      <span className="vp__corner vp__corner--tl" />
      <span className="vp__corner vp__corner--tr" />
      <span className="vp__corner vp__corner--bl" />
      <span className="vp__corner vp__corner--br" />

      {status === "OFFLINE" && (
        <div className="vp__placeholder">
          <i data-lucide="video-off" style={{ width: 36, height: 36, stroke: "var(--fg-4)" }}></i>
          <span className="label" style={{ marginTop: 12 }}>信号なし · NO SIGNAL</span>
          <span className="mono" style={{ fontSize: 11, color: "var(--fg-4)", marginTop: 4 }}>
            デバイスを接続してください
          </span>
        </div>
      )}

      {status === "LINK" && (
        <div className="vp__placeholder">
          <span className="dot dot--link" style={{ width: 12, height: 12 }} />
          <span className="label" style={{ marginTop: 14 }}>Handshake...</span>
          <span className="mono" style={{ fontSize: 11, color: "var(--fg-3)", marginTop: 4 }}>
            magic 0x5350 · awaiting SPS/PPS
          </span>
        </div>
      )}

      {(status === "LIVE" || status === "READY") && (
        <>
          <div className="vp__hud vp__hud--top">
            <span>CAM-01 · ISX012 · 1280×720</span>
            <span className="vp__hud-right">
              <span className="dot dot--live" />LIVE
            </span>
          </div>
          <span className="vp__ts">{timestamp}</span>
          {recording && (
            <span className="vp__rec">
              <span className="dot dot--rec" />REC · {recElapsed}
            </span>
          )}
          <span className="vp__frame">F#{String(frameCount).padStart(6, "0")}</span>
        </>
      )}

      {status === "FAULT" && (
        <div className="vp__placeholder" style={{ color: "var(--status-fault)" }}>
          <i data-lucide="alert-triangle" style={{ width: 32, height: 32, stroke: "var(--status-fault)" }}></i>
          <span className="label" style={{ marginTop: 12, color: "var(--status-fault)" }}>FAULT · E0x07</span>
          <span className="mono" style={{ fontSize: 11, color: "var(--fg-2)", marginTop: 4 }}>
            USB stall — auto-retry 1/3
          </span>
        </div>
      )}
    </div>
  );
}

window.Viewport = Viewport;
