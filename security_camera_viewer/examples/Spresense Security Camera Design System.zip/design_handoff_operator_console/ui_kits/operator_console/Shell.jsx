// Shell.jsx — top bar, left rail, right inspector, bottom log strip
const { useState } = React;

function TopBar({ device, onDisconnect, status }) {
  return (
    <div className="topbar">
      <div className="topbar__left">
        <img src="../../assets/glyph.svg" height="22" alt="" />
        <span className="topbar__title">SPRESENSE · 防犯カメラ操作コンソール</span>
      </div>
      <div className="topbar__center">
        <span className="mono" style={{ color: "var(--fg-3)", fontSize: 11 }}>{device || "no device"}</span>
      </div>
      <div className="topbar__right">
        <StatusPill status={status} />
        <button className="btn btn--ghost" title="Settings"><i data-lucide="settings-2"></i></button>
        <button className="btn btn--ghost" title="Power"><i data-lucide="power"></i></button>
      </div>
    </div>
  );
}

function StatusPill({ status }) {
  const map = {
    LIVE:    { cls: "pill--live",    dot: "dot--live",    label: "配信中 · LIVE" },
    READY:   { cls: "pill--ready",   dot: "dot--ready",   label: "待機 · READY" },
    LINK:    { cls: "pill--link",    dot: "dot--link",    label: "接続中 · LINK" },
    OFFLINE: { cls: "pill--offline", dot: "dot--offline", label: "切断 · OFFLINE" },
    FAULT:   { cls: "pill--fault",   dot: "dot--fault",   label: "障害 · FAULT" },
  };
  const s = map[status] || map.OFFLINE;
  return (
    <span className={`pill ${s.cls}`}>
      <span className={`dot ${s.dot}`} />{s.label}
    </span>
  );
}

function LeftRail({ active, onSelect }) {
  const items = [
    { id: "stream", icon: "video",    label: "ストリーム" },
    { id: "record", icon: "circle",   label: "録画" },
    { id: "files",  icon: "folder",   label: "ファイル" },
    { id: "stats",  icon: "activity", label: "統計" },
    { id: "device", icon: "cpu",      label: "デバイス" },
  ];
  return (
    <nav className="rail">
      {items.map(it => (
        <button key={it.id}
          className={`rail__item ${active === it.id ? "is-active" : ""}`}
          onClick={() => onSelect(it.id)}
          title={it.label}>
          <i data-lucide={it.icon}></i>
          <span>{it.label}</span>
        </button>
      ))}
      <div style={{ flex: 1 }} />
      <button className="rail__item" title="ヘルプ">
        <i data-lucide="circle-help"></i>
        <span>ヘルプ</span>
      </button>
    </nav>
  );
}

function RightInspector({ children }) {
  return <aside className="inspector">{children}</aside>;
}

function BottomLog({ children }) {
  return <div className="logstrip">{children}</div>;
}

Object.assign(window, { TopBar, LeftRail, RightInspector, BottomLog, StatusPill });
