// TelemetryStrip.jsx — six-cell metric strip
function TelemetryStrip({ status, fps, bitrate, latency, frames, crcErrs }) {
  const cell = (label, value, unit, color) => (
    <div className="tcell">
      <span className="tcell__l">{label}</span>
      <span className="tcell__v" style={color ? { color } : null}>
        {value}{unit && <small>{unit}</small>}
      </span>
    </div>
  );
  return (
    <div className="tstrip">
      {cell("配信", status, null, status === "LIVE" ? "var(--status-ready)" : status === "FAULT" ? "var(--status-fault)" : null)}
      {cell("FPS", fps, "fps")}
      {cell("ビットレート", bitrate, "Mbps")}
      {cell("遅延", latency, "ms")}
      {cell("フレーム数", frames)}
      {cell("CRC エラー", crcErrs, null, crcErrs > 0 ? "var(--status-link)" : null)}
    </div>
  );
}
window.TelemetryStrip = TelemetryStrip;
