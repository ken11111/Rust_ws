// RecordingControls.jsx
function RecordingControls({ recording, recElapsed, segment, storageUsed, storageTotal, onToggle }) {
  const pct = Math.round((storageUsed / storageTotal) * 100);
  return (
    <div className="panel">
      <div className="panel__head">
        <span className="label">録画 · RECORDING</span>
        <span className="mono" style={{ fontSize: 10, color: "var(--fg-3)" }}>seg {String(segment).padStart(3, "0")}</span>
      </div>
      <div style={{ padding: 14, display: "flex", flexDirection: "column", gap: 10 }}>
        {!recording ? (
          <button className="btn btn--primary" onClick={onToggle} style={{ justifyContent: "center" }}>
            <span className="dot" style={{ background: "var(--accent-fg)" }} />録画開始
          </button>
        ) : (
          <button className="btn btn--danger" onClick={onToggle} style={{ justifyContent: "center" }}>
            <i data-lucide="square"></i>停止 · {recElapsed}
          </button>
        )}
        <hr className="divider"/>
        <span className="label">ストレージ</span>
        <div style={{ height: 6, background: "var(--bg-3)", borderRadius: 1, overflow: "hidden" }}>
          <div style={{ width: pct + "%", height: "100%", background: pct > 85 ? "var(--status-fault)" : "var(--accent)" }} />
        </div>
        <div className="kv">
          <div className="kv__row"><span>使用量</span><span>{storageUsed} / {storageTotal} GB</span></div>
          <div className="kv__row"><span>毎時</span><span>~900 MB</span></div>
          <div className="kv__row"><span>保持期間</span><span>7 日</span></div>
          <div className="kv__row"><span>最古</span><span>2025-12-14</span></div>
        </div>
      </div>
    </div>
  );
}
window.RecordingControls = RecordingControls;
