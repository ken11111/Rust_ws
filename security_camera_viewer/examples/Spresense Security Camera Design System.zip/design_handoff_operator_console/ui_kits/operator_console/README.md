# UI Kit · Operator Console (PC Viewer)

Recreates the **PC-side desktop viewer** described in `docs/security_camera/01_specifications/06_SOFTWARE_SPEC_PC_RUST.md`.

**Source of truth:** the Rust spec (Tokio + tokio-serial + ffmpeg-next + egui/eframe). No source UI exists yet — this kit is a forward-looking visual specification, faithful to the spec's data shapes (`VideoFrame`, `NalUnit`, `Packet`, `HandshakeInfo`, `RecordingFile`).

## Files
- `index.html` — interactive click-thru of the full app shell. Connect → handshake → live stream → record → fault.
- `Shell.jsx` — top bar, left rail, right inspector, bottom log strip.
- `Viewport.jsx` — live 16:9 video canvas with HUD overlay, recording state.
- `TelemetryStrip.jsx` — 6-cell metric strip (FPS, bitrate, latency, frames, CRC errs, stream).
- `ConnectionPanel.jsx` — device picker, baud, handshake, connect.
- `LogStrip.jsx` — filterable terminal log tail.
- `RecordingControls.jsx` — REC button, segment counter, storage gauge.

Components are intentionally thin (cosmetic only). They are not production Rust translations — they're high-fidelity HTML mocks built against the spec's vocabulary.
