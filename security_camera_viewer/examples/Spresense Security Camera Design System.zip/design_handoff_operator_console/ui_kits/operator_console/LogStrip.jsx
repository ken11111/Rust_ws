// LogStrip.jsx — log tail with filter + level colors
const { useState: useStateLog } = React;
function LogStrip({ entries }) {
  const [filter, setFilter] = useStateLog("ALL");
  const filtered = filter === "ALL" ? entries : entries.filter(e => e.level === filter);
  return (
    <div className="logwrap">
      <div className="logwrap__head">
        <span className="label">ログ · LOG TAIL</span>
        <div className="logwrap__filters">
          {["ALL", "INFO", "WARN", "FAULT"].map(f => (
            <button key={f} className={`logwrap__btn ${filter === f ? "is-on" : ""}`} onClick={() => setFilter(f)}>{f}</button>
          ))}
          <span className="mono" style={{ fontSize: 10, color: "var(--fg-3)", marginLeft: 8 }}>{entries.length} 行</span>
        </div>
      </div>
      <div className="loglines">
        {filtered.map((e, i) => (
          <div key={i} className="logline">
            <span className="ts">{e.t}</span>{" "}
            <span className={`lvl lvl-${e.level.toLowerCase()}`}>{e.level.padEnd(5)}</span>{" "}
            <span className="msg" dangerouslySetInnerHTML={{ __html: e.msg }} />
          </div>
        ))}
      </div>
    </div>
  );
}
window.LogStrip = LogStrip;
