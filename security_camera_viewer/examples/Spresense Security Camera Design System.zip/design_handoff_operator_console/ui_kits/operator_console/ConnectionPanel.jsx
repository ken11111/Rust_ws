// ConnectionPanel.jsx — device picker, baud, connect
const { useState: useStateConn } = React;
function ConnectionPanel({ device, status, onConnect, onDisconnect }) {
  const [dev, setDev] = useStateConn(device || "/dev/ttyACM0");
  const connected = status !== "OFFLINE" && status !== "FAULT";
  return (
    <div className="panel">
      <div className="panel__head">
        <span className="label">接続 · CONNECTION</span>
        <span className="mono" style={{ fontSize: 10, color: "var(--fg-3)" }}>SCBP v0x01</span>
      </div>
      <div style={{ padding: 14, display: "flex", flexDirection: "column", gap: 10 }}>
        <div className="field">
          <span className="label">デバイス</span>
          <select className="input" value={dev} onChange={e => setDev(e.target.value)} disabled={connected}>
            <option>/dev/ttyACM0</option>
            <option>/dev/ttyACM1</option>
            <option>/dev/ttyUSB0</option>
          </select>
        </div>
        <div className="field">
          <span className="label">ボーレート</span>
          <input className="input" defaultValue="115200" disabled={connected}/>
        </div>
        <div style={{ display: "flex", gap: 8, marginTop: 4 }}>
          {!connected ? (
            <button className="btn btn--primary" style={{ flex: 1 }} onClick={() => onConnect(dev)}>
              <i data-lucide="usb"></i>接続
            </button>
          ) : (
            <button className="btn btn--danger" style={{ flex: 1 }} onClick={onDisconnect}>
              <i data-lucide="power"></i>切断
            </button>
          )}
        </div>
        <hr className="divider"/>
        <div className="kv">
          <div className="kv__row"><span>magic</span><span>0x5350</span></div>
          <div className="kv__row"><span>protocol</span><span>MJPEG/SCBP</span></div>
          <div className="kv__row"><span>handshake</span><span style={{ color: connected ? "var(--status-ready)" : "var(--fg-3)" }}>{connected ? "成功 · 71 ms" : "—"}</span></div>
        </div>
      </div>
    </div>
  );
}
window.ConnectionPanel = ConnectionPanel;
